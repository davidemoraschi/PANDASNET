﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Xml.Linq;

namespace Consultas.Controllers
{
    public class FiltrosController : ApiController
    {
        public HttpResponseMessage Get(string valor, string campo)
        {
            string contenido = ""; int j = 0;
            string identity = User.Identity.Name; 
            HttpResponseMessage res = Request.CreateResponse(HttpStatusCode.OK);
            string origin = "";
            try
            {
                origin = Request.Headers.GetValues("Origin").ElementAt(0);
            }
            catch (Exception e)
            {
                Trace.TraceWarning("Warning: " + origin + " - " + e.StackTrace);
            }
            string dni = "";
            string json = "";
            try {
                Trace.TraceInformation(identity); 
                string uriDni = @"http://pandas.sas.junta-andalucia.es/_api/SP.UserProfiles.PeopleManager/GetUserProfilePropertyFor(accountName=@v,propertyName='NIF')?@v='" + identity + "'";
                using (var handler = new HttpClientHandler { Credentials = new NetworkCredential("srvc_ma49spandas", "SharePoint49", "DMSAS") })
                using (var client = new HttpClient(handler))
                {
                    if (identity != "")
                    {
                        var result = client.GetStringAsync(uriDni).Result; 
                        XDocument doc = XDocument.Parse(result); 
                        dni = doc.Root.Value;
                        
                        if (dni == "")
                        {
                            Trace.TraceWarning("Warning=>  User: " + identity); 
                        }
                        else
                        {
                            Trace.TraceInformation("User: " + identity + " - Dni: " + dni);

                            //string conString = "User Id=OPERACIONALES; password=oper2012exp;" + "Data Source=10.233.15.243:1521/SEE41DAE;";
                            string conString = "User Id=OPERACIONALES; password=oper2012exp;" + "Data Source=10.203.33.243:1521/mae41dae;";
                            
                            OracleConnection con = new OracleConnection();
                            con.ConnectionString = conString; j++;
                            con.Open(); j++;
                            OracleCommand cmd = con.CreateCommand(); j++;
                            cmd.CommandText = "SELECT PER_CODIGO,PER_NOMBRE,PER_APELLIDO1,PER_APELLIDO2,OPE_USER FROM REP_PRO_MAC.PERSONAS JOIN REP_PRO_MAC.OPERADOR ON (PERSONAS.PER_CODIGO = OPERADOR.OPE_PER_CODIGO) WHERE PER_ID_DOCUMENTO = UPPER ('" + dni + "')";
                            string nombre = "";
                            OracleDataReader reader = cmd.ExecuteReader();
                            string codigo = "";
                            while (reader.Read())
                            {
                                codigo = reader.GetString(0);
                                nombre = reader.GetString(4);
                            }

                            cmd.CommandText = "" +
                                "SELECT CODIGO," +
                                " NOMBRE," +
                                " DECODE (TIPO_UNIDAD," +
                                " 'UF', AH1.AH_CODIGO," +
                                " 'AH', AH2.AH_CODIGO," +
                                " 'SAS', 'SAS'," +
                                " 'SC', 'SC'," +
                                " 'UFS', 'UFS')" +
                                " AH_CODIGO," +
                                " DECODE (TIPO_UNIDAD," +
                                " 'UF', AH1.AH_DESCRIPCION," +
                                " 'AH', AH2.AH_DESCRIPCION," +
                                " 'SAS', 'Todas'," +
                                " 'SC', 'Servicios Centrales'," +
                                " 'UFS', '¿UFS?')" +
                                " AH_DESCRIPCION," +
                                " DECODE (TIPO_UNIDAD, 'UF', UF.UF_CODIGO, 'AH', NULL)" +
                                " UF_CODIGO," +
                                " UF_NOMBRE" +
                                " FROM REP_PRO_MAC.OPERADORUNIDADFUNCIONAL" +
                                " JOIN REP_PRO_MAC.MODULO" +
                                " ON (MODULO = CODIGO)" +
                                " LEFT JOIN REP_PRO_EST.UNIDADES_FUNCIONALES UF" +
                                " ON (UNIDAD = UF_CODIGO)" +
                                " LEFT JOIN REP_PRO_EST.AREAS_HOSPITALARIAS AH1" +
                                " ON (UF_AH_CODIGO = AH1.AH_CODIGO)" +
                                " LEFT JOIN REP_PRO_EST.AREAS_HOSPITALARIAS AH2" +
                                " ON (UNIDAD = AH2.AH_CODIGO)" +
                                " WHERE OPERADOR = '" + codigo + "'";

                            reader = cmd.ExecuteReader();
                            List<Par<int, List<string>>> mapa = new List<Par<int, List<string>>>();
                            int code = 0, count = 0;
                            List<string> apartados = new List<string>() { "descr_modulo", "natid_area_hospitalaria", "descr_area_hospitalaria", "natid_unidad_funcional", "descr_unidad_funcional" };
                            json = "{\"operador\":\"" + nombre + "\", \"modulos\": [";
                            while (reader.Read())
                            {
                                List<string> list = new List<string>();
                                code = reader.GetInt32(count);
                                json += "{\"natid_modulo\": \"" + code + "\",";
                                for (int i = 1; i < 6; i++)
                                {
                                    try
                                    {
                                        list.Add(reader.GetString(i));
                                        json += "\"" + apartados[i - 1] + "\": \"" + reader.GetString(i) + "\",";
                                    }
                                    catch (Exception e) { json += "\"" + apartados[i - 1] + "\": \"\","; }
                                }
                                json = json.Substring(0, json.Length - 1);
                                json += "},";
                                Par<int, List<string>> par = new Par<int, List<string>>(code, list);
                                mapa.Add(par);
                            }
                            json = json.Substring(0, json.Length - 1);
                            json += "]}";
                            
                        }

                        dynamic json2 = Newtonsoft.Json.JsonConvert.DeserializeObject(json); j++;
                        int contador_modulos = json2.modulos.Count; j++;
                        bool tiene_valores = false;
                        contenido = "{\"Filtros\":["; j++;
                        for (int i = 0; i < contador_modulos; i++)
                        {
                            string natid = json2.modulos[i].natid_modulo;
                            string descr = json2.modulos[i].descr_modulo;
                            if (valor == natid || valor == descr)
                            {
                                contenido += "{\""+campo+"\":\""+devCampo(campo, json2.modulos[i])+"\"},";
                                tiene_valores = true;
                            }
                        }
                        if(tiene_valores)
                            contenido = contenido.Substring(0, contenido.Length - 1) + "]}";
                        else
                            contenido += "]}";
                    }
                }
            }catch(Exception e){
                contenido = dni + "------" + identity + "------" + j + "------" + json + "------" + e.StackTrace + "------" + e.Message;
            }
            res.Headers.Add("Access-Control-Allow-Origin", origin);
            res.Headers.Add("Access-Control-Allow-Credentials", "true");
            res.Content = new StringContent(contenido, Encoding.UTF8, "application/json");
            return res;
        }

        public string devCampo(string campo, dynamic json)
        {
            if(campo == "natid_area_hospitalaria"){
                return json.natid_area_hospitalaria;
            }else if (campo == "descr_area_hospitalaria"){
                return json.descr_area_hospitalaria;
            }else if(campo == "natid_unidad_funcional"){
                return json.natid_unidad_funcional;
            }else if(campo == "descr_unidad_funcional"){
                return json.descr_unidad_funcional;
            }else if (campo == "natid_modulo"){
                return json.natid_modulo;
            }else if (campo == "descr_modulo"){
                return json.descr_modulo;
            }
            return "";
        }
    }
}
