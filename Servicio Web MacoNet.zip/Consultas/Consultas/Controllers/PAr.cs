﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Consultas.Controllers
{
    public class Par<T,T1>
    {
        int code {get; set;}
        List<string> list { get; set; }

        public Par(int code, List<string> list){
            this.code = code;
            this.list = list;
        }


    }
}