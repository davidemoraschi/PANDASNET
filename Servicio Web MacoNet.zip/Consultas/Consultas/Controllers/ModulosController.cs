﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;

namespace Consultas.Controllers
{
    public class ModulosController : ApiController
    {
        public HttpResponseMessage Get(string dni)
        {
            string conString = "User Id=OPERACIONALES; password=oper2012exp;" + "Data Source=10.233.15.243:1521/SEE41DAE;";            
            string contenido = "";
             //EZ Connect Format is [hostname]:[port]/[service_name]
                //Examine working TNSNAMES.ORA entries to find these values
            //Create a connection to Oracle
            OracleConnection con = new OracleConnection(); 
            try
            { 
                con.ConnectionString = conString;
                con.Open();
            }
            catch (Exception e)
            {
                contenido += "<br/>"+ e.Message +"<br/>";
            }
                //Create a command within the context of the connection
                //Use the command to display employee names and salary from Employees table
            string json = "";
            try
            {
                OracleCommand cmd = con.CreateCommand();
                cmd.CommandText = "SELECT PER_CODIGO,PER_NOMBRE,PER_APELLIDO1,PER_APELLIDO2,OPE_USER FROM REP_PRO_MAC.PERSONAS JOIN REP_PRO_MAC.OPERADOR ON (PERSONAS.PER_CODIGO = OPERADOR.OPE_PER_CODIGO) WHERE PER_ID_DOCUMENTO = UPPER ('"+dni+"')";
                string nombre = "";
                OracleDataReader reader = cmd.ExecuteReader();
                string codigo = "";
                while (reader.Read())
                {
                    codigo = reader.GetString(0) ;
                    nombre = reader.GetString(4);
                } 
                
                cmd.CommandText = "" +
                    "SELECT CODIGO," +
                    " NOMBRE," +
                    " DECODE (TIPO_UNIDAD," +
                    " 'UF', AH1.AH_CODIGO," +
                    " 'AH', AH2.AH_CODIGO," +
                    " 'SAS', 'SAS'," +
                    " 'SC', 'SC'," +
                    " 'UFS', 'UFS')" +
                    " AH_CODIGO," +
                    " DECODE (TIPO_UNIDAD," +
                    " 'UF', AH1.AH_DESCRIPCION," +
                    " 'AH', AH2.AH_DESCRIPCION," +
                    " 'SAS', 'Todas'," +
                    " 'SC', 'Servicios Centrales'," +
                    " 'UFS', '¿UFS?')" +
                    " AH_DESCRIPCION," +
                    " DECODE (TIPO_UNIDAD, 'UF', UF.UF_CODIGO, 'AH', NULL)" +
                    " UF_CODIGO," +
                    " UF_NOMBRE" +
                    " FROM REP_PRO_MAC.OPERADORUNIDADFUNCIONAL" +
                    " JOIN REP_PRO_MAC.MODULO" +
                    " ON (MODULO = CODIGO)" +
                    " LEFT JOIN REP_PRO_EST.UNIDADES_FUNCIONALES UF" +
                    " ON (UNIDAD = UF_CODIGO)" +
                    " LEFT JOIN REP_PRO_EST.AREAS_HOSPITALARIAS AH1" +
                    " ON (UF_AH_CODIGO = AH1.AH_CODIGO)" +
                    " LEFT JOIN REP_PRO_EST.AREAS_HOSPITALARIAS AH2" +
                    " ON (UNIDAD = AH2.AH_CODIGO)" +
                    " WHERE OPERADOR = '"+ codigo +"'" ;

                reader = cmd.ExecuteReader();
                List<Par<int, List<string>>> mapa = new List<Par<int, List<string>>>();
                int code=0, count= 0;
                List<string> apartados = new List<string>() { "descr_modulo", "natid_area_hospitalaria", "descr_area_hospitalaria", "natid_unidad_funcional", "descr_unidad_funcional" };
                json = "{\"operador\":\"" + nombre + "\", \"modulos\": [";
                while (reader.Read())
                {
                    List<string> list = new List<string>();
                    code = reader.GetInt32(count);
                    json += "{\"natid_modulo\": \""+code+"\",";
                    for (int i = 1; i < 6;i++ ){
                        try
                        {
                            list.Add(reader.GetString(i));
                            json += "\""+ apartados[i-1]+"\": \""+reader.GetString(i)+"\",";
                        }
                        catch (Exception e) { json += "\"" + apartados[i - 1] + "\": \"\","; }
                    }
                    json = json.Substring(0, json.Length - 1);
                    json += "},";
                    Par<int, List<string>> par = new Par<int, List<string>>(code,list);                    
                    mapa.Add(par);
                }
                json = json.Substring(0, json.Length - 1);
                json += "]}";
                //Execute the command and use datareader to display the data
            }catch(Exception e){
                contenido += "<br/>" + e.Message + "<br/>";
            }
            HttpResponseMessage res = Request.CreateResponse(HttpStatusCode.OK);
            res.Content = new StringContent(json, Encoding.UTF8, "application/json");
            return res;
        }
    }
}
