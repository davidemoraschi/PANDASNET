﻿using CacheCow.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace Consultas
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Configuración y servicios de API web

            // Rutas de API web
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApiFiltros",
                routeTemplate: "{controller}/{valor}/{campo}",
                defaults: new { id = RouteParameter.Optional }
            );
            config.Routes.MapHttpRoute(
                name: "DefaultApiModulos",
                routeTemplate: "{controller}/{dni}",
                defaults: new { id = RouteParameter.Optional }
            );
            GlobalConfiguration.Configuration.MessageHandlers.Add(new CachingHandler(GlobalConfiguration.Configuration));
        }
    }
}
