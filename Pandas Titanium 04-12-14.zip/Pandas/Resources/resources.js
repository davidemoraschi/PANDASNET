function resources(credenciales,url) {
	Ti.UI.backgroundColor = 'white';
	var win = Ti.UI.createWindow({
		title:'Resources',
	});	
	var table;
	var recursos;
	var jsonRes;
	var actInd = Ti.UI.createActivityIndicator({
		width:150,
		height:150,
		style: Ti.UI.ActivityIndicatorStyle.DARK,
		message: 'Cargando...',
		color: 'white',
		indicatorColor: '#fff'
	});
	win.add(actInd);
	request();
	Ti.API.log('url: '+url);
	
	function request() {
		actInd.show();
		var Ntlm = require("ti.ntlm");
		var urlAux = url;
		var corte=urlAux.split("?");
		Ti.API.log(corte);
		

		var client = Ti.Network.createHTTPClient({
		    // function called when the response data is available
		    onload : function() {
		    	jsonRes = JSON.parse(this.responseText)["value"];
		    	var aux = "";
		    	recursos = new Array(jsonRes.length);
		    	
		    	for ( var i=0; i<jsonRes.length; i++) {
					aux = jsonRes[i].name;
					recursos[i] = {"title":aux};
		    	}
		    	
		    	// MARK: - TableView con informes
		    	table = Ti.UI.createTableView({
					  data: recursos,
					  font : {
				        fontSize : 20,
				        fontFamily : 'Helvetica Neue'
				    	}
				});
				actInd.hide();
				win.add(table);
				table.addEventListener('click', function(e) {
					
			    	var dialog = Titanium.UI.createOptionDialog({
					    options: ['CSV','HTML','JSON','PNG','XLSX','PDF','Cancelar'],
					    //'PDF'
					    
					    cancel:6
					});		
					
					var format_list = ['csv','html','json','png','xlsx','pdf','c'];
					//,'pdf'
					
					var formato="&$format=";
					var datosInforme = jsonRes[e.index];
					var urlInforme = datosInforme["url"];
					dialog.show();
					if (datosInforme["kind"] == undefined){
						dialog.addEventListener('click',function(e){
							if(dialog.getSelectedIndex()!=6){
								formato += format_list[e.index];
								var showResource = require('/showResource');
								new showResource(credenciales,corte[0]+"/"+urlInforme+"?"+corte[1]+"&$css=1"+formato,format_list[e.index]).open();
							}
						});
					}else{
						dialog.addEventListener('click',function(e){
							if(dialog.getSelectedIndex()!=6){
								formato += format_list[e.index];
								var showResource = require('/showResource');
								new showResource(credenciales,corte[0]+"/"+urlInforme+"?"+corte[1]+"&"+datosInforme["description"]+"&$css=1"+formato,format_list[e.index]).open();
							}
						});
					} 			
				
		
		});
			},
			    
		    // function called when an error occurs, including a timeout
		    onerror : function(e) {
		        Ti.API.info(e.error);
		      	//var servers = require('/Pandas/Resources/servers.js');
		        //var serverWindow = new serversWindowFunction();
		        //serverWindow.open();
		    },
		    connected : function() {
		    },
		    timeout : 10000  // in milliseconds
		});
		client.username = credenciales[0];
		client.password = credenciales[1];
		client.domain = credenciales[2];
		//ANDROID SPECIFIC CODE STARTS.
		client.addAuthFactory(Ntlm.getAuthScheme(),Ntlm.getAuthFactory());
		//ANDROID SPECIFIC CODE ENDS. 
		
		// Prepare the connection.
		client.open("GET", urlAux);
		// Send the request.
		client.send();
	}
	return win;
}
module.exports = resources;