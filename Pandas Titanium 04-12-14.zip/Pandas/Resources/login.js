function login() {
	var proyectos;
	
	var url = "http://ws-pandasnet.sas.junta-andalucia.es/v1"; 
	var mainWindow = Titanium.UI.createWindow({  
	    title:'Login',
	    backgroundColor:'#fff'
	});
	
	var loginView = Titanium.UI.createView({
		title: 'Login',
		backgroundColor: '#fff'
	});
	
	var userTextField = Ti.UI.createTextField({
		top:'10%',
		borderRadius:3,
		hintText:'username',
		keyboardType:Titanium.UI.KEYBOARD_DEFAULT,
		width:'80%',
		height:'auto',
		left:'10%',
		right:'10%',
		touchEnabled: true,
		color: '#151515', 
		value : 'srvc_ma49spandas'
	});
	loginView.add(userTextField);
	
	var passTextField = Ti.UI.createTextField({
		top:'30%',
		borderRadius:3,
		hintText:'password',
		keyboardType:Titanium.UI.KEYBOARD_DEFAULT,
		width:'80%',
		height:'auto',
		left:'10%',
		right:'10%',
		touchEnabled: true,
		passwordMask: true, 
		color: '#151515',
		value:'SharePoint49'
	});
	loginView.add(passTextField);
	
	var loginBtn = Titanium.UI.createButton({  
		title:'Login',  
		top:'50%',  
		width:'60%',  
		height:'15%',  
		borderRadius:1,  
		font:{fontFamily:'Arial',fontWeight:'bold',fontSize:14}
	  
	}); 
	
	loginView.add(loginBtn);
	loginBtn.addEventListener('click', authenticate);
	mainWindow.add(loginView);
	
	var picker = Ti.UI.createPicker({
		top: '80%',
		color: '#ffffff'
	});
	
	var data = [];
	data[0]=Ti.UI.createPickerRow({title:'dev'});
	data[1]=Ti.UI.createPickerRow({title:'pro'});
	data[2]=Ti.UI.createPickerRow({title:'pre'});
	
	picker.add(data);
	picker.selectionIndicator = true;
	
	var actInd = Ti.UI.createActivityIndicator({
		width:150,
		height:150,
		style: Ti.UI.ActivityIndicatorStyle.DARK,
		message: 'Cargando...',
		color: 'black',
		indicatorColor: '#fff'
	});
	mainWindow.add(picker);
	mainWindow.add(actInd);


	picker.setSelectedRow(0, 0, false); // Selected dev as default

	
	function authenticate() {
		actInd.show();
		var urlAux = url + "/" + picker.getSelectedRow(false).title + "/Projects";;
		var Ntlm = require("ti.ntlm");
		var jsonRes;
		var credenciales = new Array(userTextField.value,passTextField.value,"DMSAS");
		
		var client = Ti.Network.createHTTPClient({
		    // function called when the response data is available
		    onload : function(e) {
		    	jsonRes = JSON.parse(this.responseText)["value"];
		    	var aux = "";
		    	proyectos = new Array(jsonRes.length);
		    	
		    	for ( var i=0; i<jsonRes.length; i++) {
					aux = jsonRes[i].name;
					proyectos[i] = {"title":aux};
		    	}
		    	
		    	var projects = require('/projects');
		    	actInd.hide();
		    	new projects(credenciales,proyectos,url +"/"+ picker.getSelectedRow(false).title).open();
		    },
		    // function called when an error occurs, including a timeout
		    onerror : function(e) {
		        Ti.API.info(e.error);
		      	//var servers = require('/Pandas/Resources/servers.js');
		        //var serverWindow = new serversWindowFunction();
		        //serverWindow.open();
		    },
		    connected : function(e) {
				alert("Login conectado");
		    },
		    timeout : 10000  // in milliseconds
		});
		client.username = userTextField.value;
		client.password = passTextField.value;
		client.domain = 'DMSAS';
		//ANDROID SPECIFIC CODE STARTS.
		client.addAuthFactory(Ntlm.getAuthScheme(),Ntlm.getAuthFactory());
		//ANDROID SPECIFIC CODE ENDS. 
		
		// Prepare the connection.
		client.open("GET", urlAux);
		// Send the request.
		client.send();
	}
	return mainWindow;	
}
module.exports = login;