// this sets the background color of the master UIView (when there are no windows/tab groups on it)


Titanium.UI.setBackgroundColor('#000');

var tabGroup = Titanium.UI.createTabGroup();



//
// create base UI tab and root window
//

var login = require('/login');
new login().open();

