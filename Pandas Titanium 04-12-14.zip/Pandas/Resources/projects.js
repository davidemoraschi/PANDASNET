function projects(credenciales,proyectos,url) {
		
	Ti.UI.backgroundColor = '#fff'; 

	var win = Ti.UI.createWindow({
		title:'Projects',
	});
	

	var tableData = proyectos;
	
	var table = Ti.UI.createTableView({
	  //backgroundColor: '#000',
	  //top: '10%',
	  data: tableData,
	});
	win.add(table);
	
	table.addEventListener('click', function(e) {
		var proyecto = proyectos[e.index]["title"];
		
		var resources = require('/resources');
		new resources(credenciales,url+"/"+proyecto+"/"+"Reports?$device=android").open();
	});
	
	return win;
}
module.exports = projects;