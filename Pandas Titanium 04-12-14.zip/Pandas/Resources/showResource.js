function showResource(credenciales,urlAux,formato) {
		
	Ti.UI.backgroundColor = '#fff'; 

	var win = Ti.UI.createWindow({
		title:'Show resource',
	});
	request();
	
	function request() {
		var Ntlm = require("ti.ntlm");
		

		var client = Ti.Network.createHTTPClient({
		    // function called when the response data is available
		    onload : function() {
		    	var webView = Titanium.UI.createWebView();
		    	if(formato != "pdf" && formato != "html"){
		    		webView.setData(this.responseData);
		    		win.add(webView);
		    	}else if (formato == "html"){
		    		webView.setHtml(this.responseText);
		    		win.add(webView);
		    	}else{
					try {
					    var f = Ti.Filesystem.getFile('your.pdf');
					    Ti.Android.currentActivity.startActivity(Ti.Android.createIntent({
					        action: Ti.Android.ACTION_VIEW,
					        type: 'application/pdf',
					        data: f.getNativePath()
					    }));
					}
					catch (err) {
					    var alertDialog = Titanium.UI.createAlertDialog({
					        title: 'No PDF Viewer',
					        message: 'We tried to open a PDF but failed. Do you want to search the marketplace for a PDF viewer?',
					        buttonNames: ['Yes','No'],
					        cancel: 1
					    });
					    alertDialog.show();
					    alertDialog.addEventListener('click', function(evt) {
					        if (evt.index == 0) {
					            Ti.Platform.openURL('http://search?q=pdf');
					        }
					    });
					}
		    	//Titanium.Blob;
		    	//var informe = Titanium.UI.createWebView({url:url});
		    }	
				},
		    // function called when an error occurs, including a timeout
		    onerror : function(e) {
		        Ti.API.info(e.error);
		    },
		    connected : function() {
		    },
		    timeout : 10000  // in milliseconds
		});
		client.username = credenciales[0];
		client.password = credenciales[1];
		client.domain = credenciales[2];
		//ANDROID SPECIFIC CODE STARTS.
		client.addAuthFactory(Ntlm.getAuthScheme(),Ntlm.getAuthFactory());
		//ANDROID SPECIFIC CODE ENDS. 
		
		// Prepare the connection.
		client.open("GET", urlAux);
		// Send the request.
		client.send();
	}
	
	
return win;
}
module.exports=showResource;