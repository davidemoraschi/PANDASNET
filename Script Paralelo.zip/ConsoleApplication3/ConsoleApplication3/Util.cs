﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Util
    {
        public static string GetType(JTokenType t)
        {
            string res = "";
            if (t == JTokenType.String)
                res = "Text";
            else if (t == JTokenType.Integer)
                res = "Number";
            else if (t == JTokenType.Date)
                res = "DateTime";
            return res;
        }
    }
}
