﻿using Microsoft.SharePoint.Client;
using SP = Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Threading;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            string server = args[0];
            string project = args[1];
            string reportID = args[2];
            string rutaLista = args[3];
            string nombreLista = args[4];
            int FibonacciCalculations = Convert.ToInt32(args[5]);//64;

            Console.Write("server: " + server + " \nProject: " + project + " \nReport: " + reportID + " \nRuta: " + rutaLista + " \nNombre: " +
                nombreLista + " \nfib: " + FibonacciCalculations.ToString());

            int skip = 0;
            ManualResetEvent[] doneEvents = new ManualResetEvent[FibonacciCalculations];
            int ndoneEvents = 0;
            int cont = Inicializar(reportID, server, project, rutaLista, nombreLista);
            int div = cont / 100;
            for (int i = 0; i < (cont / 100) + 1; i++)
            {
                doneEvents[ndoneEvents] = new ManualResetEvent(false);
                var envelop = RunAsyncMultiple(reportID, skip.ToString(), server, project, rutaLista, nombreLista);
                Sharepoint f = new Sharepoint(envelop, doneEvents[ndoneEvents], rutaLista , new HttpResponseMessage());
                ThreadPool.QueueUserWorkItem(f.ThreadPoolCallback, i);
                ndoneEvents++;
                if ((i > 0) & ((i % 63) == 0))
                {
                    WaitHandle.WaitAll(doneEvents);
                    ndoneEvents = 0;
                }
                if (!f.res.IsSuccessStatusCode)
                    Console.Write(f.res.StatusCode.ToString() + " - Error");
                skip += 100;
            }
            Console.ReadLine();
        }

        static int Inicializar(string reportID, string server, string project, string rutaLista, string nombreLista)
        {
            //Comprobar si existe la lista
            ClientContext context_comprobacion = new ClientContext(rutaLista);
            Web web_comprobacion = context_comprobacion.Web;
            context_comprobacion.Credentials = new System.Net.NetworkCredential("srvc_ma49spandas", "SharePoint49", "DMSAS");
            context_comprobacion.Load(web_comprobacion.Lists,
                         lists => lists.Include(list_comp => list_comp.Title,
                                                list_comp => list_comp.Id));
            context_comprobacion.ExecuteQuery();
            bool existe_lista = false;
            foreach (List list_comp in web_comprobacion.Lists)
            {
                if (nombreLista == list_comp.Title)
                {
                    existe_lista = true;
                    break;
                }
            }

            ClientContext context = new ClientContext(rutaLista);
            Web web = context.Web;
            context.Credentials = new System.Net.NetworkCredential("srvc_ma49spandas", "SharePoint49", "DMSAS");
            //Se borra la lista
            if (existe_lista)
            {
                List list_delete = web.Lists.GetByTitle(nombreLista);
                list_delete.DeleteObject();
            }
            //Se crea la lista de nuevo
            ListCreationInformation creationInfo = new ListCreationInformation();
            creationInfo.Title = nombreLista;
            creationInfo.TemplateType = (int)ListTemplateType.GenericList;
            List list = web.Lists.Add(creationInfo);
            list.Description = "My list description";
            int contador = 0;
            using (var handler = new HttpClientHandler { Credentials = new NetworkCredential("srvc_ma49spandas", "SharePoint49", "DMSAS") })
            using (var client = new HttpClient(handler))
            {
                //Se crean los campos columna y se crean las entradas, filas.
                string uri_ws = @"http://ws-pandasnet.sas.junta-andalucia.es/v1/" + server + "/" + project + "/Reports/" + reportID + "?$format=json&$top=1";
                string result = client.GetStringAsync(uri_ws).Result;
                dynamic s = JsonConvert.DeserializeObject(result);
                JArray stuff = s.d.results;
                contador = s.d.__count;

                string name = "";
                string valor = "";
                foreach (JObject content in stuff.Children<JObject>())
                {
                    foreach (JProperty prop in content.Properties())
                    {
                        name = prop.Name;
                        valor = prop.Value.ToString();
                        JTokenType t = prop.Value.Type;
                        SP.Field field = list.Fields.AddFieldAsXml("<Field DisplayName='" + name + "' Type='" + Util.GetType(t) + "' />",
                                                    true,
                                                    AddFieldOptions.DefaultValue);
                        if (t == JTokenType.Integer)
                        {
                            SP.FieldNumber fld = context.CastTo<FieldNumber>(field);
                            fld.MaximumValue = 100;
                            fld.MinimumValue = 0;
                            fld.Update();
                        }
                        else if (t == JTokenType.String)
                        {
                            SP.FieldText fld = context.CastTo<FieldText>(field);
                            fld.Update();
                        }
                        else if (t == JTokenType.Date)
                        {
                            SP.FieldDateTime fld = context.CastTo<FieldDateTime>(field);
                            fld.Update();
                        }
                    }
                    break;
                }

                context.ExecuteQuery();
            }
            return contador;
        }

        static MultipartContent RunAsyncMultiple(string reportID, string skip, string server, string project, string rutaLista, string nombreLista)
        {
            using (var handler = new HttpClientHandler { Credentials = new NetworkCredential("srvc_ma49spandas", "SharePoint49", "DMSAS") })
            using (var client = new HttpClient(handler))
            {
                ClientContext context = new ClientContext(rutaLista);
                Web web = context.Web;
                context.Credentials = new System.Net.NetworkCredential("srvc_ma49spandas", "SharePoint49", "DMSAS");
                List list = context.Web.Lists.GetByTitle(nombreLista);
                context.ExecuteQuery();
                
                string uri_ws = @"http://ws-pandasnet.sas.junta-andalucia.es/v1/" + server + "/" + project + "/Reports/" + reportID + "?$format=json&$top=100&$skip=" + skip;
                string result = client.GetStringAsync(uri_ws).Result;
                dynamic s = JsonConvert.DeserializeObject(result);
                JArray stuff = s.d.results;
                int contador_elem = 1;
                var content2 = new MultipartContent("mixed");
                string name = "";
                string valor = "";

                foreach (JObject content in stuff.Children<JObject>())
                {
                    ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                    ListItem newItem = list.AddItem(itemCreateInfo);
                    var multigizmo1 = "POST /" + "" + nombreLista +" HTTP/1.1\n" +
                        "Content-ID: " + contador_elem + "\n" +
                        "Content-Type: application/json\n" +
                        "Accept: application/json\n" +
                        "\n" +
                        "{\"Título\": \"Elem" + contador_elem + "\",";
                    foreach (JProperty prop in content.Properties())
                    {
                        name = prop.Name;
                        valor = prop.Value.ToString();
                        if (prop.Value.Type == JTokenType.Date)
                        {
                            string[] valores = valor.Split(new char[] { '/', ':',' ' });
                            if (valores[3].Length == 1)
                                valores[3] = "0" + valores[3];
                            valor = valores[2] + "-"+ valores[1] +"-" +valores[0] +"T"+ valores[3] +":"+ valores[4] +":"+ valores[5]+"";
                        }
                        multigizmo1 += "\"" + name + "\": \"" + valor + "\", ";
                    }
                    contador_elem++;
                    multigizmo1 = multigizmo1.Substring(0, multigizmo1.Length - 2) + "}";
                    HttpContent stringContent1 = new StringContent(multigizmo1);
                    stringContent1.Headers.ContentType = new MediaTypeHeaderValue("application/http");
                    stringContent1.Headers.Add("Content-Transfer-Encoding", "binary");
                    content2.Add(stringContent1);
                }

                var envelope = new MultipartContent("mixed");
                envelope.Add(content2);

                return envelope;
            }
        }
    }
}
