﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Sharepoint
    {
        private ManualResetEvent _doneEvent;
        private MultipartContent _envelop;
        private string _rutaLista;
        private HttpResponseMessage _res;

        public HttpResponseMessage res { get { return _res; } }

        public Sharepoint(MultipartContent envelop, ManualResetEvent doneEvent, string rutaLista, HttpResponseMessage res)
        {
            _doneEvent = doneEvent;
            _envelop = envelop;
            _rutaLista = rutaLista;
            _res = res;
        }

        public void ThreadPoolCallback(Object threadContext)
        {
            int threadIndex = (int)threadContext;
            _res = Post(_envelop).Result;
            _doneEvent.Set();
        }

        public async Task<HttpResponseMessage> Post(MultipartContent envelop)
        {
            using (var handler = new HttpClientHandler { Credentials = new NetworkCredential("srvc_ma49spandas", "SharePoint49", "DMSAS") })
            using (var client = new HttpClient(handler))
            {
                HttpResponseMessage response = await client.PostAsync(/*http://sp13pruebas.sas.junta-andalucia.es/pandaspruebas/ */ _rutaLista + "_vti_bin/listdata.svc/$batch", envelop);
                return response;
            }
        }
    }
}
