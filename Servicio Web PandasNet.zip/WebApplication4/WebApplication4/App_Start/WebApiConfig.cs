﻿using CacheCow.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace WebApplication4
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Configuración y servicios de API web

            // Rutas de API web
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApiHelp",
                routeTemplate: "v1/{controller}",
                defaults: new { }
            );
            config.Routes.MapHttpRoute(
                name: "DefaultApiv1",
                routeTemplate: "v1/{server_name}/{project_name}/{controller}/{reportID}",
                defaults: new { id = RouteParameter.Optional }
            );
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "pandas/{server_name}/{project_name}/{controller}/{reportID}",
                defaults: new { id = RouteParameter.Optional }
            );
            config.Routes.MapHttpRoute(
                name: "DefaultApiReports",
                routeTemplate: "v1/{server_name}/{project_name}/{controller}",
                defaults: new { id = RouteParameter.Optional }
            );
            config.Routes.MapHttpRoute(
                name: "DefaultApiProjects",
                routeTemplate: "v1/{server_name}/{controller}",
                defaults: new { id = RouteParameter.Optional }
            );
            
            GlobalConfiguration.Configuration.MessageHandlers.Add(new CachingHandler(GlobalConfiguration.Configuration)); 
        }
    }
}
