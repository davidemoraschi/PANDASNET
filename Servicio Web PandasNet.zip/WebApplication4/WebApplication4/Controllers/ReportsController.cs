﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Http;
using System.Xml;
using System.Xml.Linq;
using System.Diagnostics;
using System.Web;
using System.Net.Sockets;
using System.IO;
using GoogleAnalyticsTracker.WebApi2;
using System.Net.Http.Headers;
using System.Security.Principal;
using System.Drawing;

namespace WebApplication4.Controllers
{
    public class ReportsController : ApiController
    {
        public string Get()
        {
            return "v1";
        }

        [AcceptVerbs("OPTIONS")]
        public HttpResponseMessage Options()
        {
            var resp = new HttpResponseMessage(HttpStatusCode.OK);
            resp.Headers.Add("Access-Control-Allow-Origin", "*");
            resp.Headers.Add("Access-Control-Allow-Methods", "GET");

            return resp;
        }

        public HttpResponseMessage Get(string server_name, string project_name)
        {            
            HttpResponseMessage res = Request.CreateResponse(HttpStatusCode.OK);
            var uri = "";

            string user = System.Configuration.ConfigurationManager.AppSettings["creduser-" + server_name];
            string pass = System.Configuration.ConfigurationManager.AppSettings["credpass-" + server_name];
            string domain = System.Configuration.ConfigurationManager.AppSettings["creddomain-" + server_name];

            //Login
            var handler = new HttpClientHandler { Credentials = new NetworkCredential(user, pass, domain) };
            var httpClient = new HttpClient(handler);
            string sessionState = "";
            
            sessionState = Util.Login(server_name, project_name, httpClient);
            string device = Request.RequestUri.ParseQueryString().Get("$device");
            string json_final = "";

            if (device == "ios" || device == "android")
            {
                json_final = UtilMobile.jsonMobile(server_name, sessionState, httpClient);
            }
            else
            {
                //Folders
                //uri = Util.FolderBrowse(server_name, sessionState);
                uri = Util.FolderBrowse(server_name, sessionState);
                string contenido2 = httpClient.GetStringAsync(uri).Result;

                //Xml: coge los id de los obj
                XDocument xDoc = XDocument.Parse(contenido2);
                var hijos = xDoc.Descendants("obj");

                //Creamos la cadena que dará lugar al JSON
                json_final = "{\"odata.metadata\":\"http://swpandas/pandas/$metadata\",\"value\":[";
                bool crea_json = false;
                //Por cada obj hacemos reportExecute:
                foreach (var item in hijos)
                {
                    string name = item.Element("n").Value.ToString();
                    string reportId = item.Element("id").Value.ToString();
                    //string description_rep = item.Element("d").Value.ToString();

                    if (name != "Mobile")
                    {
                        json_final += "{\"name\":\"" + name + "\",\"url\":\"" + reportId + "\"";
                        uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
                        + "?taskId=reportExecute" +
                        "&taskEnv=juil_xhr" +
                        "&taskContentType=json" +
                        "&sessionState=" + sessionState +
                        "&reportID=" + reportId +
                        "&execFlags=32768";
                        string para_msgId = httpClient.GetStringAsync(uri).Result;

                        //Si es status = 1 me salto esto ; si status = 2 entonces tiene prompts
                        dynamic json_reportExecute = Newtonsoft.Json.JsonConvert.DeserializeObject(para_msgId);
                        int status = json_reportExecute.status;
                        string msgId = json_reportExecute.id;
                        if (status == 2) // Hago el getPrompts
                        {
                            json_final += ",\"kind\":\"PromptedReport\",\"prompts\":[";
                            uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
                            + "?taskId=getPrompts" +
                            "&taskEnv=juil_xhr" +
                            "&taskContentType=json" +
                            "&msgID=" + msgId +
                            "&objectType=3" +
                            "&sessionState=" + sessionState;
                            string prompts = httpClient.GetStringAsync(uri).Result;
                            dynamic json_prompts = Newtonsoft.Json.JsonConvert.DeserializeObject(prompts);
                            int contador_prompts = json_prompts.prompts.Count;
                            List<int> prompts_list = new List<int>();
                            string attributeId = "", descrip = "";
                            int count_prompt_vp = 0, count_prompt_op = 0, count_prompt_jer = 0;
                            if (json_prompts.prompts[0].ptp == 2) // Elemento
                            {
                                attributeId = json_prompts.prompts[0].orgn.did;
                                descrip = json_prompts.prompts[0].orgn.n;
                            }
                            else if (json_prompts.prompts[0].ptp == 1) // Valor
                            {
                                attributeId = "vp" + count_prompt_vp;
                                descrip = json_prompts.prompts[0].ttl;
                                count_prompt_vp++;
                            }
                            else if (json_prompts.prompts[0].ptp == 4) // Object
                            {
                                attributeId = "op" + count_prompt_op;
                                descrip = json_prompts.prompts[0].n;
                                count_prompt_op++;
                            }
                            else // Jerarquia se supone ptp=3
                            {
                                attributeId = "jerarquia" + count_prompt_jer;
                                descrip = json_prompts.prompts[0].ttl;
                                count_prompt_jer++;
                            }
                            json_final += "{\"AttributeId\":\"" + attributeId + "\",\"AttributeName\":\"" + descrip + "\"}";
                            for (int i = 1; i < contador_prompts; i++)
                            {
                                if (json_prompts.prompts[i].ptp == 2) // Elemento
                                {
                                    attributeId = json_prompts.prompts[i].orgn.did;
                                    descrip = json_prompts.prompts[i].orgn.n;
                                }
                                else if (json_prompts.prompts[i].ptp == 1) // Valor
                                {
                                    attributeId = "vp" + count_prompt_vp;
                                    descrip = json_prompts.prompts[i].ttl;
                                    count_prompt_vp++;
                                }
                                else if (json_prompts.prompts[i].ptp == 4) // Object
                                {
                                    attributeId = "op" + count_prompt_op;
                                    descrip = json_prompts.prompts[i].n;
                                    count_prompt_op++;
                                }
                                else // Jerarquia se supone ptp=3
                                {
                                    attributeId = "jerarquia" + count_prompt_jer;
                                    descrip = json_prompts.prompts[i].ttl;
                                    count_prompt_jer++;
                                }
                                json_final += ",{\"AttributeId\":\"" + attributeId + "\",\"AttributeName\":\"" + descrip + "\"}";
                            }
                            json_final += "]";
                            //json_final += ",\"description\":\"" + description_rep + "\"";
                        }
                        json_final += "},";
                        crea_json = true;
                    }
                }
                if(crea_json)
                    json_final = json_final.Substring(0, json_final.Length - 1) + "]}";
                else 
                    json_final += "]}";
            }

            //Logout
            Util.Logout(server_name, sessionState, httpClient);

            res.Content = new StringContent(json_final, Encoding.UTF8, "application/json");
            return res;
        }

        public HttpResponseMessage Get(string server_name, string project_name, string reportID)
        {
            Trace.TraceInformation(Request.RequestUri.ToString());
            string origin = "";
            try
            {
                origin = Request.Headers.GetValues("Origin").ElementAt(0);
            }catch(Exception e){
                Trace.TraceWarning("Warning: " + origin + " - " + e.StackTrace);
            }
            string identity = User.Identity.Name;

            string user = System.Configuration.ConfigurationManager.AppSettings["creduser-" + server_name];
            string pass = System.Configuration.ConfigurationManager.AppSettings["credpass-" + server_name];
            string domain = System.Configuration.ConfigurationManager.AppSettings["creddomain-" + server_name];

            Trace.TraceInformation(identity);
            string dni = "";
            string uriDni = @"http://pandas.sas.junta-andalucia.es/_api/SP.UserProfiles.PeopleManager/GetUserProfilePropertyFor(accountName=@v,propertyName='NIF')?@v='" + identity + "'";
            using (var handler = new HttpClientHandler { Credentials = new NetworkCredential("srvc_ma49spandas", "SharePoint49", "DMSAS") })
            using (var client = new HttpClient(handler))
            {
                if (identity != "")
                {
                    var result = client.GetStringAsync(uriDni).Result;
                    XDocument doc = XDocument.Parse(result);
                    dni = doc.Root.Value;
                    if (dni == "")
                    {
                        Trace.TraceWarning("Warning=>  User: " + identity );
                    }
                    else
                    {
                        Trace.Write("User: " + identity + " - Dni: " + dni);
                    }
                }
            }

            //Header Accept
            HttpRequestHeaders header = Request.Headers;
            HttpHeaderValueCollection<MediaTypeWithQualityHeaderValue> accept = header.Accept;
            string contentType = "";
            var httpClient = new HttpClient();

            //Login
            HttpResponseMessage res ;
            string sessionState = "";
            using (var handler = new HttpClientHandler { Credentials = new NetworkCredential(user, pass, domain) })
            using (var client = new HttpClient(handler))
            {
                try
                {
                    sessionState = Util.Login(server_name, project_name, httpClient);
                    res = Request.CreateResponse(HttpStatusCode.OK);
                }
                catch (Exception e)
                {
                    Trace.TraceError(e.StackTrace);
                    res = Request.CreateResponse(HttpStatusCode.InternalServerError);
                }
            }
            //Analizar Accept
            for (int i = 0; i < accept.Count; i++ )
            {
                MediaTypeWithQualityHeaderValue a = accept.ElementAt(i);
                bool csv = Regex.IsMatch(a.ToString(), @"text/csv");
                bool json_patt = Regex.IsMatch(a.ToString(), @"application/json");
                bool pdf = Regex.IsMatch(a.ToString(), @"application/pdf");
                bool excel = Regex.IsMatch(a.ToString(), @"application/vnd.ms-excel");
                bool png = Regex.IsMatch(a.ToString(), @"image/png");
                bool jsonp = Regex.IsMatch(a.ToString(), @"application/jsonp");
                if (csv)
                {
                    contentType = "text/csv";
                    break;
                }
                else if (json_patt)
                {
                    contentType = "application/json";
                    break;
                }
                else if (pdf)
                {
                    contentType = "application/pdf";
                    break;
                }
                else if (excel)
                {
                    contentType = "application/vnd.ms-excel";
                    break;
                }
                else if (png)
                {
                    contentType = "image/png";
                    break;
                }
                else if (jsonp)
                {
                    contentType = "application/jsonp";
                    break;
                }
                else
                {
                    contentType = "text/html"; 
                }
            }

            //Parser format
            contentType = Util.ParserFormat(Request);

            string uri = "";

            if (contentType == "text/csv" || contentType == "application/json")
            {
                //Ejecuto Task ExportReport
                uri = Util.ExportReport(server_name, sessionState, reportID);
            }
            else if (contentType == "application/pdf")
            {
                //Ejecuto Task ExportReport con executionMode=REPORT_MODE_PDF
                uri = Util.ExportReportPdf(server_name, sessionState, reportID);
            }
            else if (contentType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            {
                //Ejecuto Task ExportReport con executionMode=REPORT_MODE_EXCEL
                uri = Util.ExportReportExcel(server_name, sessionState, reportID);
            }
            else if (contentType == "image/png")
            {
                //Ejecuto Task ReportExecute
                uri = Util.ReportExecutPng(server_name, sessionState, reportID);
                string para_msgId = httpClient.GetStringAsync(uri).Result;
                dynamic json_reportExecute = Newtonsoft.Json.JsonConvert.DeserializeObject(para_msgId);
                int status = json_reportExecute.status;
                string msgId = json_reportExecute.id;
                uri = Util.ReportGraphic(server_name, sessionState, msgId, Request);
            }
            else if (contentType == "application/jsonp")
            {
                //Ejecuto Task ReportDataService
                uri = Util.ReportDataServiceMonstruo(server_name, project_name, reportID);
            }
            else if (contentType == "text/html")
            {
                //Ejecuto Task ReportDataService
                uri = Util.ReportDataService(server_name, project_name, reportID);
                //Parseo de $css
                string css = Request.RequestUri.ParseQueryString().Get("$css");
                uri = Util.ParserCss(css, uri);
            }

            string contenido = "";
            //Parseo de $filter y acceso a Maco
            
            string dolarFilter = Request.RequestUri.ParseQueryString().Get("$filter");
            var wi = (WindowsIdentity) User.Identity;
            var wic = (WindowsImpersonationContext) null;
            if(!wi.IsAnonymous)
                wic = wi.Impersonate();
            try {
                if (wi.IsAnonymous) {
                    using (var client = new WebClient())
                    {
                        client.Credentials = new NetworkCredential(user, pass, domain);
                        uri = Util.ParserFilter(uri, dolarFilter, client);
                    }
                }
                else
                    using ( var client = new WebClient { UseDefaultCredentials = true })
                    {
                        uri = Util.ParserFilter(uri, dolarFilter, client);
                    }
            }
            catch (Exception e)
            {
                contenido = dni + "------" + identity +  "-----" + e.StackTrace + "------" + e.Message;
            }
            finally
            {
                if (!wi.IsAnonymous)
                    wic.Undo();
            }

            //Parser de top y skip en un futuro    
            uri = Util.ParserTopSkip(uri, Request);

            //Google Analitics
            Tracker tracker = new Tracker("UA-40777680-2", "ws-pandasnet.sas.junta-andalucia.es");
            tracker.TrackPageViewAsync(Request, "Google Analytics");
            
            //Comprobar estado del servidor
            string estado_servidor = httpClient.GetStringAsync(Util.checkState(server_name)).Result;
            //Actualizar contenido de la página
            if (contentType == "text/csv"){
                var bytes = httpClient.GetByteArrayAsync(uri);
                contenido = Util.tratarArrayBytes(bytes.Result,res );
            }
            else if(contentType == "application/json"){
                var bytes = httpClient.GetByteArrayAsync(uri);
                contenido = Util.tratarArrayBytes(bytes.Result, res);
                string uri2 = Util.ReportDataServiceCount(server_name, project_name, reportID);
                string fil = Request.RequestUri.ParseQueryString().Get("$filter");

                if (!wi.IsAnonymous)
                    wic = wi.Impersonate();
                try
                {
                    if (wi.IsAnonymous)
                    {
                        using (var client = new WebClient())
                        {
                            client.Credentials = new NetworkCredential(user, pass, domain);
                            uri2 = Util.ParserFilter(uri2, fil, client);
                        }
                    }
                    else
                        using (var client = new WebClient { UseDefaultCredentials = true })
                        {
                            uri2 = Util.ParserFilter(uri2, fil, client);
                        }
                }
                catch (Exception e)
                {
                    contenido = dni + "------" + identity + "-----" + e.StackTrace + "------" + e.Message;
                }
                finally
                {
                    if (!wi.IsAnonymous)
                        wic.Undo();
                }
                
                string xml = httpClient.GetStringAsync(uri2).Result;
                try
                {
                    contenido = Util.ConvertJson(contenido, xml);
                }catch(Exception e){
                    Trace.TraceError(e.StackTrace);
                }
                res.Headers.Add("Access-Control-Allow-Origin", origin);
                res.Headers.Add("Access-Control-Allow-Credentials", "true");
            }
            else if (contentType == "application/pdf" || contentType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            {
                var bytes = httpClient.GetByteArrayAsync(uri);                
                res.Content = new ByteArrayContent(bytes.Result);
                res.Content.Headers.ContentLength = (long)bytes.Result.Length;
                res.Content.Headers.ContentType = new MediaTypeHeaderValue(contentType);
            }
            else if (contentType == "image/png")
            {
                try
                {
                    var xml_png = httpClient.GetStringAsync(uri);
                    XDocument xDoc = XDocument.Parse(xml_png.Result);
                    var temp_inBase64 = xDoc.Descendants("eb").ElementAt(0).Value;
                    byte[] temp_backToBytes = Convert.FromBase64String(temp_inBase64);
                    MemoryStream memoryStream = new MemoryStream(temp_backToBytes);
                    memoryStream.Position = 0;
                    Image image = Image.FromStream(memoryStream, true);
                    res.Content = new ByteArrayContent(temp_backToBytes);
                    res.Content.Headers.ContentLength = (long)temp_backToBytes.Length;
                    res.Content.Headers.ContentType = new MediaTypeHeaderValue(contentType);
                }catch(Exception e){
                    string a = e.Message;
                }
            }
            else{
                contenido = httpClient.GetStringAsync(uri).Result;
                string patt = @"sg\s*=\s*'[^\']*'";
                if (Regex.IsMatch(contenido, patt)) //Si hay errores
                {
                    Match valor0 = Regex.Match(contenido, patt);
                    string d = valor0.Value;
                    d = d.Substring(7, d.Length - 9);
                    contenido = d;
                    Trace.TraceError(contenido);
                    res.StatusCode = HttpStatusCode.InternalServerError;
                }
                if (contentType == "application/jsonp")
                {
                    contentType = contentType.Substring(0, contentType.Length - 1);
                    contenido = contenido.Replace('\'', '"');
                    contenido = contenido.Replace("\\n", "");
                    res.Headers.Add("Access-Control-Allow-Origin", origin);
                    res.Headers.Add("Access-Control-Allow-Credentials", "true");
                }
            }
            //Logout
            Util.Logout(server_name, sessionState, httpClient);
            if (contentType != "application/pdf" && contentType != "image/png" && contentType != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                res.Content = new StringContent(contenido, Encoding.UTF8, contentType);
            return res;
        }
    }
}
