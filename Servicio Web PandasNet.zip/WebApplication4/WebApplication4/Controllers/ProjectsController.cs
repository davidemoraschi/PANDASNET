﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;

namespace WebApplication4.Controllers
{
    public class ProjectsController : ApiController
    {
        public HttpResponseMessage Get(string server_name)
        {
            HttpResponseMessage res = Request.CreateResponse(HttpStatusCode.OK);
            var uri = "";

            //Login
            var httpClient = new HttpClient();
            string sessionState = Util.LoginSinProject(server_name, httpClient);

            uri = System.Configuration.ConfigurationManager.AppSettings[server_name] + "?taskId=searchMetadata&rootFolderID=73F7482211D3596C60001B8F67019608&taskEnv=juil_xhr&taskContentType=json&sessionState=" + sessionState;
            string contenido = httpClient.GetStringAsync(uri).Result;
            //Creamos la cadena que dará lugar al JSON
            dynamic json = Newtonsoft.Json.JsonConvert.DeserializeObject(contenido);
            int contador = json.totalSize;
            string json_final = "{\"odata.metadata\":\"http://swpandas/pandas/$metadata\",\"value\":[";
            for (int i = 0; i < contador; i++)
            {
                json_final += "{\"name\":\"" + json.items[i].n.Value + "\"},";
            }
            json_final = json_final.Substring(0, json_final.Length - 1) + "]}";
            //Logout
            Util.Logout(server_name, sessionState, httpClient);

            res.Content = new StringContent(json_final, Encoding.UTF8, "application/json");
            return res;
        }
    }
}
