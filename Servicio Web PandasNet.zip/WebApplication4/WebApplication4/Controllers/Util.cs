﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Xml;
using System.Xml.Linq; 

namespace WebApplication4.Controllers
{
    public static class Util
    {
        public static Dictionary<string, string> GetQueryStrings(this HttpRequestMessage request)
        {
            return request.GetQueryNameValuePairs()
                          .ToDictionary(kv => kv.Key, kv => kv.Value, StringComparer.OrdinalIgnoreCase);
        }

        public static string LoginSinProject(string server_name, HttpClient httpClient)
        {
            string server = System.Configuration.ConfigurationManager.AppSettings["server-" + server_name];
            string user_name = System.Configuration.ConfigurationManager.AppSettings["user-" + server_name];
            string password_name = System.Configuration.ConfigurationManager.AppSettings["password-" + server_name];
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=login" +
            "&taskEnv=juil_xhr" +
            "&taskContentType=json" +
            "&Server=" + server +
            "&userid=" + user_name +
            "&password=" + password_name;
            string contenido = httpClient.GetStringAsync(uri).Result;
            dynamic stuff = Newtonsoft.Json.JsonConvert.DeserializeObject(contenido);
            return stuff.sessionState;
        }

        public static string Login(string server_name, string project_name, HttpClient httpClient)
        {
            string server = System.Configuration.ConfigurationManager.AppSettings["server-" + server_name];
            string user_name = System.Configuration.ConfigurationManager.AppSettings["user-" + server_name];
            string password_name = System.Configuration.ConfigurationManager.AppSettings["password-" + server_name];
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=login" +
            "&taskEnv=juil_xhr" +
            "&taskContentType=json" +
            "&Server=" + server +
            "&Project=" + project_name +
            "&userid=" + user_name +
            "&password=" + password_name;
            string contenido = httpClient.GetStringAsync(uri).Result;
            dynamic stuff = Newtonsoft.Json.JsonConvert.DeserializeObject(contenido);
            return stuff.sessionState;
        }

        public static void Logout(string server_name, string sessionState, HttpClient httpClient)
        {
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=logout" +
            "&taskEnv=juil_xhr" +
            "&taskContentType=json" +
            "&sessionState=" + sessionState;
            string contenido3 = httpClient.GetStringAsync(uri).Result;
        }

        public static string ParserFilter(string uri, string dolarFilter, WebClient client)
        {
            if (!string.IsNullOrEmpty(dolarFilter))
            {
                string[] collection_and = dolarFilter.Split(new string[] { "and" }, StringSplitOptions.RemoveEmptyEntries);
                List<string> collection_valor_final = new List<string>();
                List<string> collection_IDvalor_final = new List<string>();
                List<string> collection_obj_final = new List<string>();
                List<string> collection_IDobj_final = new List<string>();
                Dictionary<string, List<string>> par_valor = new Dictionary<string, List<string>>();
                List<string> collection_IDelem_final = new List<string>();
                List<string> collection_elem_final = new List<string>();
                foreach (string elem in collection_and)
                {
                    string valor = @"vp\d+";
                    Match valor_ = Regex.Match(elem, valor);
                    string patt = @"((\d?\d/\d?\d/\d\d\d\d( \d\d:\d\d:\d\d)?)|(\w|\d)+|(\'.+\'))";
                    string patt_obj = @"\'.+\'";
                    string[] collection_ = elem.Split(new string[] { "eq" }, StringSplitOptions.RemoveEmptyEntries);
                    if (valor_.Value.Length > 0)
                     {// Es por valor (vp0,vp1..)  
                        collection_IDvalor_final.Add(valor_.Value);
                        Match valor0 = Regex.Match(collection_[1], patt);
                        string d = valor0.Value;
                        if (valor0.Length > 0)
                            if (valor0.Value[0] == '\'')
                                d = valor0.Value.Substring(1, valor0.Value.Length - 2);
                        collection_valor_final.Add(d);
                    }
                    else if (Regex.IsMatch(elem, @"op\d+")) // Es objeto
                    {
                        Match obj_ = Regex.Match(elem, @"op\d+");
                        Match valor0 = Regex.Match(collection_[1], patt_obj);
                        collection_IDobj_final.Add(obj_.Value);
                        string d = valor0.Value;
                        if (valor0.Length > 0)
                            if (d[0] == '\'')
                                d = d.Substring(1, d.Length - 2);
                        collection_obj_final.Add(d);
                    }
                    else // Es elemento
                    {
                        Match valor0 = Regex.Match(collection_[0], patt);
                        collection_IDelem_final.Add(valor0.Value);
                        Match valor1 = Regex.Match(collection_[1], patt);
                        string d = valor1.Value;
                        if (valor1.Length > 0){
                            if (valor1.Value[0] == '\'')
                                d = valor1.Value.Substring(1, valor1.Value.Length - 2);
                        }
                        if (Regex.IsMatch(collection_[1], @"^\s*{"))
                        {
                            string[] collection_2 = collection_[1].Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                            if (Regex.IsMatch(collection_2[0],@"maco"))
                            {
                                string uriMaco = "http://ws-maconet.sas.junta-andalucia.es/Filtros/" + collection_2[1] + "/" + collection_2[2].Substring(0,collection_2[2].Length-1);                               
                                string contenidoMaco = client.DownloadString(uriMaco);
                                
                                DataSet jsonMaco = Newtonsoft.Json.JsonConvert.DeserializeObject<DataSet>(contenidoMaco);
                                DataTable dataTable = jsonMaco.Tables["Filtros"];
                                for (int i = 0; i < dataTable.Rows.Count ; i++ )
                                {
                                    string elem_maco = (string)dataTable.Rows[i].ItemArray.ElementAt(0);
                                    collection_elem_final.Add(elem_maco);
                                    if (i > 0)
                                        collection_IDelem_final.Add(valor0.Value);
                                }
                            }
                        }
                        else
                        {
                            collection_elem_final.Add(d);
                        }
                    }
                }
                if (collection_valor_final.Count > 0)
                {
                    uri += "&valuePromptAnswers=";
                    for (int i = 0; i < collection_valor_final.Count; i++)
                    {
                        string id = collection_IDvalor_final[i];
                        string an = @"\d+";
                        Match vp = Regex.Match(id, an);
                        if (Convert.ToInt32(vp.Value) - i > 0)
                            for (int j = 0; j < Convert.ToInt32(vp.Value) - i; j++)
                                uri += "^";
                        uri += collection_valor_final[i] + "^";
                    }
                }
                if (collection_obj_final.Count > 0)
                {
                    uri += "&objectsPromptAnswers=";
                    for (int i = 0; i < collection_obj_final.Count; i++)
                    {
                        string id = collection_IDobj_final[i];
                        uri += collection_obj_final[i] + "^";
                    }
                }
                if (collection_IDelem_final.Count > 0)
                {
                    uri += "&elementsPromptAnswers=";
                    string aux = collection_IDelem_final[0];
                    bool es_elem_sas_o_sc = true;
                    for (int i = 0; i < collection_IDelem_final.Count; i++)
                    {
                        string id = collection_IDelem_final[i];
                        string elem = collection_elem_final[i];
                        if (elem != "SAS" && elem != "SC")
                        {
                            if (aux != id)
                            {
                                uri = uri.Substring(0, uri.Length - 1);
                                uri += ",";
                            }
                            aux = id;
                            uri += id + ";";
                            uri += id + ":" + elem + ";";
                        }
                    }
                    //uri = uri.Substring(0, uri.Length - 1);
                }
                //uri += "&promptAnswerMode=2";
            }
            uri += "&promptAnswerMode=2";
            return uri;
        }

        public static string ParserCss(string css, string uri)
        {
            if (!string.IsNullOrEmpty(css))
            {
                if (Convert.ToInt32(css) == 1)
                    css = "ReportGridiPhoneStyle";
                else
                    css = "ReportGridStyle-ForExportDocumentsExcel";
            }
            else
                css = "ReportGridStyle-ForExportDocumentsExcel";
            uri += "&styleName=" + css;
            return uri;
        }

        public static string ParserTopSkip(string uri, HttpRequestMessage request)
        {
            Dictionary<string, string> queryParameters = GetQueryStrings(request);
            int top = 1000, skip = 1;
            if (queryParameters.ContainsKey("$top"))
            {
                top = Convert.ToInt32(queryParameters["$top"]);
            }
            if (queryParameters.ContainsKey("$skip"))
            {
                skip = Convert.ToInt32(queryParameters["$skip"]) + 1;
            }
            uri += "&maxRows=" + top + "&startRow=" + skip;
            return uri;
        }

        public static string ParserFormat(HttpRequestMessage request)
        {
            Dictionary<string, string> queryParameters = GetQueryStrings(request);
            string format = "";
            if (queryParameters.ContainsKey("$format"))
            {
                format = Convert.ToString(queryParameters["$format"]);
                if (format == "json")
                    format = "application/json";
                else if (format == "csv")
                    format = "text/csv";
                else if (format == "pdf")
                    format = "application/pdf";
                else if (format == "xlsx")
                    format = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                else if (format == "png")
                    format = "image/png";
                else if (format == "megajson")
                    format = "application/jsonp";
                else
                    format = "text/html";
            }
            else
                format = "text/html";
            return format;
        }

        public static string ReportDataService( string server_name, string project_name, string reportID)
        {
            string server = System.Configuration.ConfigurationManager.AppSettings["server-" + server_name];
            string user_name = System.Configuration.ConfigurationManager.AppSettings["user-" + server_name];
            string password_name = System.Configuration.ConfigurationManager.AppSettings["password-" + server_name];
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=reportDataService" +
            "&taskEnv=html" +
            "&maxCols=256" +
            "&taskContentType=html" +
            "&Server=" + server +
            "&Project=" + project_name +
            "&userid=" + user_name +
            "&password=" + password_name +
            "&reportID=" + reportID;
            return uri;
        }

        public static string ReportDataServiceMonstruo(string server_name, string project_name, string reportID)
        {
            string server = System.Configuration.ConfigurationManager.AppSettings["server-" + server_name];
            string user_name = System.Configuration.ConfigurationManager.AppSettings["user-" + server_name];
            string password_name = System.Configuration.ConfigurationManager.AppSettings["password-" + server_name];
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=reportDataService" +
            "&taskEnv=xhr" +
            "&maxCols=256" +
            "&taskContentType=jsonp" +
            "&Server=" + server +
            "&Project=" + project_name +
            "&userid=" + user_name +
            "&password=" + password_name +
            "&styleName=InteractiveGridDataStyle" +
            "&reportID=" + reportID;
            return uri;
        }

        public static string ReportDataServiceCount(string server_name, string project_name, string reportID)
        {
            string server = System.Configuration.ConfigurationManager.AppSettings["server-" + server_name];
            string user_name = System.Configuration.ConfigurationManager.AppSettings["user-" + server_name];
            string password_name = System.Configuration.ConfigurationManager.AppSettings["password-" + server_name];
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=reportDataService" +
            "&taskEnv=xml" +
            "&maxRows=1" +
            "&maxCols=1" +
            "&taskContentType=xml" +
            "&Server=" + server +
            "&Project=" + project_name +
            "&userid=" + user_name +
            "&password=" + password_name +
            "&reportID=" + reportID +
            "&styleName=IPhoneReportXMLOldStyle";
            return uri;
        }

        public static string ExportReport(string server_name, string sessionState, string reportID)
        {
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=exportReport" +
            "&taskEnv=xml" +
            "&taskContentType=xml" +
            "&sessionState=" + sessionState +
            "&reportID=" + reportID +
            "&executionMode=4" +
            "&plainTextDelimiter=|";

            return uri;
        }

        public static string ExportReportPdf(string server_name, string sessionState, string reportID)
        {
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=exportReport" +
            "&taskEnv=xml" +
            "&taskContentType=xml" +
            "&sessionState=" + sessionState +
            "&reportID=" + reportID +
            "&executionMode=2" ;

            return uri;
        }

        public static string ExportReportExcel(string server_name, string sessionState, string reportID)
        {
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=exportReport" +
            "&taskEnv=xml" +
            "&taskContentType=xml" +
            "&sessionState=" + sessionState +
            "&reportID=" + reportID +
            "&executionMode=3" +
            "&excelVersion=4";

            return uri;
        }

        public static string ReportExecutPng(string server_name, string sessionState, string reportID)
        {
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=reportExecute" +
            "&taskEnv=juil_xhr" +
            "&taskContentType=json" +
            "&sessionState=" + sessionState +
            "&reportID=" + reportID +
            "&reportViewMode=2" ;

            return uri;
        }

        public static string ReportGraphic(string server_name, string sessionState, string msg, HttpRequestMessage request)
        {
            Dictionary<string, string> queryParameters = GetQueryStrings(request);
            int width = 750, height = 400;
            if (queryParameters.ContainsKey("$width"))
            {
                width = Convert.ToInt32(queryParameters["$width"]);
            }
            if (queryParameters.ContainsKey("$height"))
            {
                height = Convert.ToInt32(queryParameters["$height"]);
            }
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=getReportGraphImage" +
            "&taskEnv=xml" +
            "&taskContentType=xml" +
            "&sessionState=" + sessionState +
            "&messageID="+ msg +
            "&imgType=2" +
            "&width=" + width+
            "&height="+ height+
            "&availWidth="+width+
            "&availHeight=" + height;

            return uri;
        }

        public static string FolderBrowse(string server_name, string sessionState)
        {
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=folderBrowse" +
            "&taskEnv=juil_xhr" +
            "&taskContentType=json" +
            "&sessionState=" + sessionState +
            "&styleName=FolderXMLStyle" +
            "&systemFolder=20";
            return uri;
        }

        public static string FolderBrowseMobile(string server_name, string sessionState)
        {
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=folderBrowse" +
            "&taskEnv=juil_xhr" +
            "&taskContentType=json" +
            "&sessionState=" + sessionState +
            "&styleName=FolderXMLStyle" +
            "&folderName=Mobile";
            return uri;
        }

        public static string FolderBrowseMobileId(string server_name, string sessionState, string folderID)
        {
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=folderBrowse" +
            "&taskEnv=juil_xhr" +
            "&taskContentType=json" +
            "&sessionState=" + sessionState +
            "&styleName=FolderXMLStyle" +
            "&folderID="+ folderID +
            "&folderName=Mobile";
            return uri;
        }

        public static string checkState(string server_name)
        {
            string server = System.Configuration.ConfigurationManager.AppSettings["server-" + server_name];
            string uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
            + "?taskId=IsServerConnected" +
            "&taskEnv=xml" +
            "&taskContentType=xml" +
            "&server=" + server ;
            return uri;
        }

        public static string ConvertJson(string contenido, string xml)
        {
            XElement XMLDatos = XElement.Parse(xml);
            var tr = (from c in XMLDatos.Descendants("report_data")
                             select c.Element("ifd").Attribute("tr").Value);
            var tc = (from c in XMLDatos.Descendants("report_data")
                             select c.Element("ifd").Attribute("tc").Value);
            int contador_line = Convert.ToInt32(tr.ElementAt(0));
            int contador_col = Convert.ToInt32(tc.ElementAt(0));

            string json = "{\"d\":{\"results\":[";
            StringReader file = new StringReader(contenido);
            string line;
            List<string> campos = new List<string>();
            bool camp = true; 
            bool hay_result = false;
            while ((line = file.ReadLine()) != null )
            {
                if (camp)
                {
                    campos = line.Split('|').ToList();
                    int aux_anterior = 1;
                    string aux = "";
                    for (int i = 0; i < campos.Count; i++)
                    {
                        if (campos[i] != "")
                        {
                            aux = campos[i];
                            aux_anterior = 1;
                        }
                        if (campos[i] == "")
                        {
                            campos[i] = aux + aux_anterior;
                            aux_anterior++;
                        }
                    }
                    for (int i = 0; i < campos.Count; i++)
                    {
                        campos[i] = campos[i].Replace(' ', '_');
                        campos[i] = campos[i].Replace(".", "");
                    }
                    camp = false;
                }
                else{
                    json += "{";
                    string[] valores = line.Split('|');
                    for (int i = 0; i < campos.Count; i++)
                    {
                        bool es_numero = Regex.IsMatch(valores[i],@"^\d+((\.|\,|\')\d+)?$");
                        bool es_date = Regex.IsMatch(valores[i], @"^\d?\d/.*");
                        if (es_numero)
                        {
                            bool empieza_por_cero = Regex.IsMatch(valores[i], @"^0");
                            if(empieza_por_cero)
                                json += "\"" + campos[i] + "\":\"" + valores[i] + "\",";
                            else
                                json += "\"" + campos[i] + "\":" + valores[i] + ",";                            
                        }
                        else if (es_date)
                        {
                            DateTime dt; var epoch = new DateTime(); long epoch_final = 0;
                            //dt = Convert.ToDateTime(valores[i]);
                            IFormatProvider culture = new System.Globalization.CultureInfo("es-ES", true);
                            dt = DateTime.Parse(valores[i], culture, System.Globalization.DateTimeStyles.AssumeLocal);
                            epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
                            epoch_final = Convert.ToInt64((dt - epoch).TotalSeconds);
                            json += "\"" + campos[i] + "\":\"/Date(" + epoch_final + "000)/\",";
                        }
                        else
                            json += "\"" + campos[i] + "\":\"" + valores[i] + "\",";                        
                    }
                    json = json.Substring(0, json.Length - 1);
                    json += "},";
                    hay_result = true;
                }
            }
            if(hay_result)
                json = json.Substring(0, json.Length - 1);
            return json + "],\"__count\":"+contador_line+"}}";
        }

        public static string tratarArrayBytes(byte[] bytes,HttpResponseMessage res)
        {
            string contenido = "";
            if(bytes.Length > 0)
                if (bytes[1] == 0) // Es Unicode(16 bits)
                    contenido = Encoding.Unicode.GetString(bytes, 0, bytes.Length);
                else // Es UTF8 y error
                {
                    contenido = Encoding.UTF8.GetString(bytes, 0, bytes.Length);
                    string patt = "sg=\"[^\"]*\"";
                    Match valor0 = Regex.Match(contenido, patt);
                    if (Regex.IsMatch(contenido, patt)) //Si hay errores
                    {
                        string d = valor0.Value;
                        d = d.Substring(5, d.Length - 7);
                        contenido = d;
                        Trace.TraceError(contenido);
                        res.StatusCode = HttpStatusCode.InternalServerError;
                    }
                }
            return contenido;
        }
    }
}