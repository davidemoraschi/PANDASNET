﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using System.Diagnostics;
using System.IO;
using System.Net.Http.Headers;

namespace WebApplication4.Controllers
{
    public class HelpController : ApiController
    {
        public HttpResponseMessage Get()
        {
            
            var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory , "App_Data/Help.html");
            HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);
            var stream = new FileStream(path, FileMode.Open);
            result.Content = new StreamContent(stream);
            result.Content.Headers.ContentType =
                new MediaTypeHeaderValue("text/html");

            return result;
        }
    }
}
