﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication4.Controllers
{
    public class MegaJson
    {
        //(function ($) {
        //        $.fn.pintarcuadriculainfra = function (options) {
        //            options = $.extend({}, $.fn.pintarcuadriculainfra.defaultOptions, options);
        //            var element = $(this);
        //            var url = options.url;
        //            var scriptpath = options.scriptpath;
        //            var csspath = options.csspath;
        //            var initialExpandDepth = options.initialExpandDepth;
        //            //Empieza codigo     
        //            var ejson = creaJSON(url, csspath, scriptpath, element, initialExpandDepth);
        //            return this;
        //        };
        //    })(jQuery);

        //    (function ($) {
        //        $.fn.pintarcuadriculainfrajson = function (options) {        
        //            options = $.extend({}, $.fn.pintarcuadriculainfrajson.defaultOptions, options);
        //            var element = $(this);
        //            var ejson = options.json;
        //            var scriptpath = options.scriptpath;
        //            var csspath = options.csspath;
        //            var initialExpandDepth = options.initialExpandDepth;
        //            if (ejson != null) {
        //                var tit = titulos(ejson);
        //                var jsonparseado = creaJSONInfra(ejson);
        //                //console.log(jsonparseado);
        //                //console.log(tit);
        //                if (tit.length == 1) {
        //                    $.ig.loader({
        //                        scriptPath: scriptpath,
        //                        cssPath: csspath,
        //                        resources: "igGrid.MultiColumnHeaders.Paging",
        //                        //theme: "metro",
        //                        locale: "es", regional: "es"
        //                    });
        //                    $.ig.loader(function () {
        //                        element.igGrid({
        //                            // 1.
        //                            width: "100%",
        //                            loadOnDemand: false,
        //                            autoGenerateColumns: false,
        //                            generateCompactJSONResponse: false,
        //                            dataSource: jsonparseado,
        //                            dataSourceType: 'json',
        //                            responseDataKey: "Records",
        //                            columns: tit[0],
        //                            features: [
        //                            { name: "MultiColumnHeaders" }
        //                            //, {
        //                            //                    name: "Paging",
        //                            //                    pageSize: 50,
        //                            //                    type: "local",
        //                            //                    recordCountKey: "TotalRecordsCount",
        //                            //                    pageIndexUrlKey: "page",
        //                            //                    pageSizeUrlKey: "pageSize"
        //                            //            }
        //                            ]
        //                        });
        //                    });
        //                }

        //                if (tit.length > 1) {
        //                    $.ig.loader({
        //                        scriptPath: scriptpath,
        //                        cssPath: csspath,
        //                        resources: "igHierarchicalGrid.MultiColumnHeaders.Paging",
        //                        //theme: "metro",
        //                        locale: "es", regional: "es"
        //                    });
        //                    $.ig.loader(function () {
        //                        var obj = {
        //                            // 2.
        //                            width: "99%",
        //                            initialExpandDepth: initialExpandDepth,
        //                            dataSource: jsonparseado,
        //                            dataSourceType: 'json',
        //                            responseDataKey: "Records",
        //                            //initialDataBindDepth: -1,
        //                            autoGenerateColumns: false,
        //                            //childrenDataProperty: "Orders",
        //                            primaryKey: "LEVEL0ID",
        //                            generateCompactJSONResponse: false,
        //                            features: [
        //                                //{
        //                                //                name: "Paging",
        //                                //                pageSize: 50,
        //                                //                type: "local",
        //                                //                recordCountKey: "TotalRecordsCount",
        //                                //                pageIndexUrlKey: "page",
        //                                //                pageSizeUrlKey: "pageSize"
        //                                //        },
        //                            { name: "MultiColumnHeaders" }
        //                            ]
        //                        };
        //                        var nodoactual = obj;
        //                        for (var key = 0; key < tit.length; key++) {
        //                            nodoactual["columns"] = tit[key];
        //                            var level = "LEVEL" + (key + 1);
        //                            var secondlevel = {
        //                                //  Define looks and behavior for the second level in the hierarchy
        //                                key: level,
        //                                responseDataKey: "Records",
        //                                // 3.
        //                                width: "99%",
        //                                autoGenerateColumns: false,
        //                                //defaultcolumnwidth: "200",
        //                                generateCompactJSONResponse: false,
        //                                foreignKey: "LEVEL0ID",
        //                                features: [{
        //                                    name: "MultiColumnHeaders"
        //                                },
        //                                ]
        //                            };

        //                            if (key != tit.length - 1)
        //                                nodoactual["columnLayouts"] = [secondlevel];
        //                            nodoactual = secondlevel;
        //                        }
        //                        element.igHierarchicalGrid(obj);
        //                    });
        //                }
        //            }
        //            else {
        //                alert("El Servicio Web no pudo ser cargado");
        //            }
        //            return this;
        //        };
        //    })(jQuery);

        //    function creaJSON(url, csspath, scriptpath, elem, initialExpandDepth) {
        //        $.support.cors = true;
        //        // add ajax transport method for cross domain requests when using IE9
        //        if ('XDomainRequest' in window && window.XDomainRequest !== null) {
        //            $.ajaxTransport("+*", function (options, originalOptions, jqXHR) {
        //                // verify if we need to do a cross domain request
        //                // if not return so we don't break same domain requests
        //                if (typeof options.crossDomain === 'undefined' || !options.crossDomain) {
        //                    return;
        //                }
        //                var xdr;
        //                return {
        //                    send: function (headers, completeCallback) {
        //                        // Use Microsoft XDR
        //                        xdr = new XDomainRequest();
        //                        xdr.open("get", options.url); // NOTE: make sure protocols are the same otherwise this will fail silently
        //                        xdr.onload = function () {
        //                            if (this.contentType.match(/\/xml/)) {
        //                                var dom = new ActiveXObject("Microsoft.XMLDOM");
        //                                dom.async = false;
        //                                dom.loadXML(this.responseText);
        //                                completeCallback(200, "success", [dom]);
        //                            } else {
        //                                completeCallback(200, "success", [this.responseText]);
        //                            }
        //                        };
        //                        xdr.onprogress = function () { };
        //                        xdr.ontimeout = function () {
        //                            completeCallback(408, "error", ["The request timed out."]);
        //                        };
        //                        xdr.onerror = function () {
        //                            completeCallback(404, "error", ["The requested resource could not be found."]);
        //                        };
        //                        xdr.send();
        //                    },
        //                    abort: function () {
        //                        if (xdr) xdr.abort();
        //                    }
        //                };
        //            });
        //        }

        //        $.ajax({
        //            url: url,
        //            dataType: "json",
        //            //data: data,
        //            //async: false,
        //            error: function (XMLHttpRequest, textStatus, errorThrown) {
        //                //alert(textStatus);
        //                alert(errorThrown.description);
        //            },
        //            success: function (data, status) {
        //                var options1 =
        //                     {
        //                         json: data,
        //                         scriptpath: scriptpath,
        //                         csspath: csspath,
        //                         initialExpandDepth: initialExpandDepth
        //                     };
        //                elem.pintarcuadriculainfrajson(options1);
        //            }
        //        });
        //    }

        //    function creagroup(columnas, nombrepadre) {
        //        var group = [];
        //        if (columnas.length == 1) {
        //            //CASO BASE
        //            var coltitle = columnas[0].es;
        //            for (var i in coltitle) {
        //                var key2 = "K" + nombrepadre + i;
        //                var htext = coltitle[i].n;
        //                htext = parsearHTML(htext);
        //                //var basictemplate="{{if esCode(${"+key2+"})}} ${"+key2+"} {{else}} <div style=\"float:right;  \"> ${"+key2+"} </div> {{/if}}";     
        //                var titlegroup = {
        //                    key: key2,
        //                    headerText: htext,
        //                    //dataType : "string",
        //                    formatter: formathtml
        //                };
        //                group.push(titlegroup);
        //            }
        //        }
        //        else if (columnas.length > 1) {
        //            var coltitle = columnas[0].es;
        //            for (var i in coltitle) {
        //                var htext = coltitle[i].n;
        //                htext = parsearHTML(htext);
        //                var grouphijo = creagroup(columnas.slice(1, columnas.length), i);
        //                var titlegroup = {
        //                    headerText: htext,
        //                    group: grouphijo
        //                };
        //                group.push(titlegroup);
        //            }
        //        }
        //        return group;
        //    }

        //    function titulos(json) {
        //        var gts = json.gts;
        //        var gvs = json.gvs;
        //        var ghs = json.ghs;
        //        var valuerow = gts.row;
        //        //var cabecera = creagrou(gts.col);
        //        var arrayc = gts.col.slice(0, gts.col.length);
        //        var groupc = creagroup(arrayc, "");
        //        var htext = gts.col[0].n;
        //        htext = parsearHTML(htext);
        //        var cabecera = {
        //            width: "60%",
        //            headerText: htext,
        //            group: groupc
        //        };
        //        var titles = [];
        //        for (var index in valuerow) {
        //            var key2 = "LEVEL" + index + "ID";
        //            var title = [{
        //                key: key2,
        //                dataType: "string",
        //                hidden: true,
        //            },
        //            {
        //                key: "K" + key2,
        //                headerText: valuerow[index].n,
        //                width: "20%",
        //                dataType: "string"

        //            }];
        //            title.push(cabecera);
        //            titles.push(title);
        //        }
        //        return titles;
        //    }

            //public  Array creaJSONInfra(dynamic json) {
            //    var gts = json.gts;
            //    var gvs = json.gvs;
            //    var ghs = json.ghs;
            //    var items = ghs.rhs.items;
            //    var valuerow = gts.row;
            //    var records = new int[]{};
            //    var padreid = 0;
            //    var primeritem = items[0].items;
            //    var nivelfinal = primeritem.length - 1;
            //    var tablareferencia = records;
            //    int[][] arraygrande = new int[][]{};
            //    for (var indexcol = 0; indexcol < gts.col.length; indexcol++) {
            //        int[] arraycol = gts.col[indexcol].es;
            //        arraygrande[indexcol] = arraycol;
            //    }
            //    int[] escalar = rec_prodesc(arraygrande);
            //    int ind_key = 0;
            //    foreach (var key in items) {
            //        var itemsinternos = items[ind_key].items;
            //        ind_key++;
            //        foreach (var j in itemsinternos) {
            //            var relaciones = j;
            //            var nivel = relaciones.tui;
            //            var v = relaciones.v;
            //            if (nivel == 0) {
            //                //PRIMER NIVEL
            //                var padre = creapadre(relaciones.o, relaciones.idx, nivel, -1, gts, gvs, escalar, v);
            //                tablareferencia[nivel].Records.push(padre);
            //                var level = "LEVEL" + (nivel + 1);
            //                tablareferencia[nivel + 1] = padre;
            //            } else if (nivel != 0 && nivel != nivelfinal) {
            //                //NIVELES INTERMEDIOS
            //                if (relaciones.idx != -1) {
            //                    var padre = tablareferencia[nivel];
            //                    var padreid = padre["LEVEL0ID"];
            //                    var padreinter = creapadre(relaciones.o, relaciones.idx, nivel, padreid, gts, gvs, escalar, v);
            //                    if (padreinter["LEVEL" + nivel + "ID"] == 0) {
            //                    } else {
            //                        var level = "LEVEL" + (nivel);
            //                        padre[level].Records.push(padreinter);
            //                        tablareferencia[nivel + 1] = padreinter;
            //                    }
            //                }
            //            } else {
            //                //NIVELFINAL
            //                if (relaciones.idx != -1) {
            //                    var padre = tablareferencia[nivel];
            //                    var hijo = creahijo(relaciones.o, relaciones.idx, nivel, padre["LEVEL0ID"], gts, gvs, escalar, v);
            //                    if (hijo["LEVEL" + nivel + "ID"] == 0) {
            //                    } else {
            //                        var level = "LEVEL" + (nivel);
            //                        var nodo = tablareferencia[nivel];
            //                        nodo[level].Records.push(hijo);
            //                    }
            //                }
            //            }
            //        }
            //    }
            //    return records;
            //}

            ////function actualizatabla(tabla, nivel, elem) {
            ////    if (tabla[nivel] == null) {
            ////        tabla[nivel] = [elem];
            ////    } else {
            ////        tabla[nivel].push(elem);
            ////    }
            ////}

            //public int[] creapadre(int o, int idx, int nivel, int padreid, dynamic gts, dynamic gvs, int[] escalar, int v) {
            //    // var indexcolum=gts.col.length-1;
            //    int[] padre = new int[]{};
            //    int level = "LEVEL" + nivel + "ID";
            //    padre[level] = idx;
            //    if (padreid != -1) {
            //        padre["LEVEL0ID"] = padreid;
            //    }
            //    var rowkey = "K" + level;
            //    //console.log(rowkey);
            //    var rowvalue = gts.row[nivel].es[idx].n;
            //    rowvalue = parsearHTML(rowvalue);
            //    padre[rowkey] = rowvalue;
            //    for (var key in escalar) {
            //        if (key != 'size') {
            //            var colkey = "K" + key;
            //            var indexitems = escalar[key];
            //            var colvalue = gvs.items[o].items[indexitems].v;
            //            padre[colkey] = colvalue;
            //        }
            //    }
            //    var level = "LEVEL" + (nivel + 1);
            //    padre[level] = {
            //        Records: []
            //    };
            //    return padre;
            //}

            //function creahijo(o, idx, nivel, padreid, gts, gvs, escalar, v) {
            //    var hijo = {};
            //    hijo["LEVEL" + nivel + "ID"] = idx;
            //    hijo["LEVEL0ID"] = padreid;
            //    var rowkey = "KLEVEL" + nivel + "ID";
            //    var rowvalue = gts.row[nivel].es[idx].n;
            //    rowvalue = parsearHTML(rowvalue);
            //    hijo[rowkey] = rowvalue;
            //    for (var key in escalar) {
            //        if (key != 'size') {
            //            var colkey = "K" + key;
            //            var indexitems = escalar[key];
            //            var colvalue = gvs.items[o].items[indexitems].v;
            //            hijo[colkey] = colvalue;
            //        }
            //    }
            //    return hijo;
            //}

            public int[] rec_prodesc(int[][] arrayg)
            {
                int[] res = new int[arrayg.Length];
                //console.log(arrayg.length);
                if (arrayg.Length == 1)
                {
                    int[] elem = arrayg[0];
                    int cont = 0;
                    foreach (int i in elem)
                    {
                        res[i] = i;
                        cont++;
                    }
                }
                else if (arrayg.Length > 1)
                {
                    res = prod_esc(rec_prodesc(Slice(arrayg, 0, (uint)arrayg.Length - 1)), rec_prodesc(Slice(arrayg, 0, (uint)arrayg.Length)));
                }
                return res;
            }

            public  int[][] Slice(int[][] arr, uint indexFrom, uint indexTo)
            {
                if (indexFrom > indexTo) {
                    throw new ArgumentOutOfRangeException("indexFrom is bigger than indexTo!");
                }

                uint length = indexTo - indexFrom;
                uint length_vector = (uint)arr[0].Length;
                int[][] result = new int[length][];
                for (int i = 0; i < length; i++ )
                    result[i] = new int[length_vector];
                Array.Copy(arr, indexFrom, result, 0, length);

                return result.ToArray();
            }

            public int[] prod_esc(int[] arraya,int[] arrayb) {
                int[] res = new int[arraya.Length * arrayb.Length];
                var i = 0;
                foreach (int indi in arraya) {
                    var j = 0;
                    foreach (int indj in arrayb) {
                        var key = 10*i+j;
                        var value = i * arrayb.Length + j;
                        res[key] = value;
                        j++;
                    }
                    i++;
                }
                return res;
            }

            //function actualizapadre(padre, hijo, gts) {
            //    var indexcolum = gts.col.length - 1;
            //    var arraycol = gts.col[indexcolum].es;
            //    for (var key in arraycol) {
            //        var colkey = gts.col[indexcolum].es[key].n;
            //        padre[colkey] = hijo[colkey];

            //    }
            //}

            //function parsearHTML(cadena) {
            //    var resultado;
            //    if (cadena.toLowerCase().indexOf('&lt;code&gt;') > -1) {
            //        //HTML
            //        var arresultado = cadena.split('&lt;code&gt;');
            //        var htext = (arresultado[1].split('&lt;/code&gt;'))[0];
            //        htext = htext.replace(/&lt;/g, "<");
            //        htext = htext.replace(/&gt;/g, ">");
            //        htext = htext.replace(/&quot;/g, "\"");
            //        resultado = htext.replace(/&amp;/g, "&");
            //    } else {
            //        //TEXT
            //        resultado = cadena;
            //    }
            //    return resultado;
            //}

            //function esCode(cadena) {
            //    var enc = false;
            //    if (cadena.toLowerCase().indexOf('&lt;code&gt;') > -1) {
            //        enc = true;
            //    }
            //    return enc;
            //}

            //function formathtml(val) {
            //    var resultado = "";
            //    if (esCode(val)) {
            //        resultado += parsearHTML(val);
            //    }
            //    else {
            //        resultado += "<div style=\"float:right;  \"> " + val + " </div>";
            //    }
            //    return resultado;
            //}

    }
}