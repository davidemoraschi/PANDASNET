﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Xml.Linq;

namespace WebApplication4.Controllers
{
    public class UtilMobile
    {
        public static string jsonMobile(string server_name, string sessionState, HttpClient httpClient)
        {
            //Folders para Mobile
            //uri = Util.FolderBrowse(server_name, sessionState);
            string uri = Util.FolderBrowseMobile(server_name, sessionState);
            string contenido_Mobile = httpClient.GetStringAsync(uri).Result;

            //Xml: coge los id de los obj
            XDocument xDoc_Mobile = XDocument.Parse(contenido_Mobile);
            var hijos_Mobile = xDoc_Mobile.Descendants("obj");

            //Creamos la cadena que dará lugar al JSON
            string json_final_Mobile = "{\"odata.metadata\":\"http://swpandas/pandas/$metadata\",\"value\":[";

            //Para informes compartidos, coger la carpeta Mobile
            foreach (var item in hijos_Mobile)
            {
                string name = item.Element("n").Value.ToString();
                string reportId = item.Element("id").Value.ToString();
                if (name == "Mobile")
                {
                    uri = Util.FolderBrowseMobileId(server_name, sessionState, reportId);
                    contenido_Mobile = httpClient.GetStringAsync(uri).Result;

                    //Xml: coge los id de los obj
                    XDocument xDoc_Mobile_Dentro = XDocument.Parse(contenido_Mobile);
                    var hijos_rep_mob = xDoc_Mobile_Dentro.Descendants("obj");

                    //Por cada obj hacemos reportExecute:
                    foreach (var item_Mobile in hijos_rep_mob)
                    {
                        string name_rep_mob = item_Mobile.Element("n").Value.ToString();
                        string reportId_rep_mob = item_Mobile.Element("id").Value.ToString();
                        string description_rep_mob = item_Mobile.Element("d").Value.ToString();

                        json_final_Mobile += "{\"name\":\"" + name_rep_mob + "\",\"url\":\"" + reportId_rep_mob + "\"";
                        uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
                        + "?taskId=reportExecute" +
                        "&taskEnv=juil_xhr" +
                        "&taskContentType=json" +
                        "&sessionState=" + sessionState +
                        "&reportID=" + reportId_rep_mob +
                        "&execFlags=32768";
                        string para_msgId = httpClient.GetStringAsync(uri).Result;

                        //Si es status = 1 me salto esto ; si status = 2 entonces tiene prompts
                        dynamic json_reportExecute = Newtonsoft.Json.JsonConvert.DeserializeObject(para_msgId);
                        int status = json_reportExecute.status;
                        string msgId = json_reportExecute.id;
                        if (status == 2) // Hago el getPrompts
                        {
                            json_final_Mobile += ",\"kind\":\"PromptedReport\",\"prompts\":[";
                            uri = System.Configuration.ConfigurationManager.AppSettings[server_name]
                            + "?taskId=getPrompts" +
                            "&taskEnv=juil_xhr" +
                            "&taskContentType=json" +
                            "&msgID=" + msgId +
                            "&objectType=3" +
                            "&sessionState=" + sessionState;
                            string prompts = httpClient.GetStringAsync(uri).Result;
                            dynamic json_prompts = Newtonsoft.Json.JsonConvert.DeserializeObject(prompts);
                            int contador_prompts = json_prompts.prompts.Count;
                            List<int> prompts_list = new List<int>();
                            string attributeId = "", descrip = "";
                            int count_prompt_vp = 0, count_prompt_op = 0, count_prompt_jer = 0;
                            if (json_prompts.prompts[0].ptp == 2) // Elemento
                            {
                                attributeId = json_prompts.prompts[0].orgn.did;
                                descrip = json_prompts.prompts[0].orgn.n;
                            }
                            else if (json_prompts.prompts[0].ptp == 1) // Valor
                            {
                                attributeId = "vp" + count_prompt_vp;
                                descrip = json_prompts.prompts[0].ttl;
                                count_prompt_vp++;
                            }
                            else if (json_prompts.prompts[0].ptp == 4) // Object
                            {
                                attributeId = "op" + count_prompt_op;
                                descrip = json_prompts.prompts[0].n;
                                count_prompt_op++;
                            }
                            else // Jerarquia se supone ptp=3
                            {
                                attributeId = "jerarquia" + count_prompt_jer;
                                descrip = json_prompts.prompts[0].ttl;
                                count_prompt_jer++;
                            }
                            json_final_Mobile += "{\"AttributeId\":\"" + attributeId + "\",\"AttributeName\":\"" + descrip + "\"}";
                            for (int i = 1; i < contador_prompts; i++)
                            {
                                if (json_prompts.prompts[i].ptp == 2)
                                {
                                    attributeId = json_prompts.prompts[i].orgn.did;
                                    descrip = json_prompts.prompts[i].orgn.n;
                                }
                                else if (json_prompts.prompts[i].ptp == 1) // Valor
                                {
                                    attributeId = "vp" + count_prompt_vp;
                                    descrip = json_prompts.prompts[i].ttl;
                                    count_prompt_vp++;
                                }
                                else if (json_prompts.prompts[i].ptp == 4) // Object
                                {
                                    attributeId = "op" + count_prompt_op;
                                    descrip = json_prompts.prompts[i].n;
                                    count_prompt_op++;
                                }
                                else // Jerarquia se supone ptp=3
                                {
                                    attributeId = "jerarquia" + count_prompt_jer;
                                    descrip = json_prompts.prompts[i].ttl;
                                    count_prompt_jer++;
                                }
                                json_final_Mobile += ",{\"AttributeId\":\"" + attributeId + "\",\"AttributeName\":\"" + descrip + "\"}";
                            }
                            json_final_Mobile += "]";
                            json_final_Mobile += ",\"description\":\"" + description_rep_mob+ "\"";
                        }
                        json_final_Mobile += "},";
                    }
                    json_final_Mobile = json_final_Mobile.Substring(0, json_final_Mobile.Length - 1);
                }
            }
            json_final_Mobile += "]}";
            return json_final_Mobile;
        }
    }
}